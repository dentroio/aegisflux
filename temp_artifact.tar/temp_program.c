#include <linux/bpf.h>
#include <linux/ip.h>
#include <linux/icmp.h>

SEC("tc")
int block_icmp_egress(struct __sk_buff *skb) {
    // Parse packet headers
    void *data = (void *)(long)skb->data;
    void *data_end = (void *)(long)skb->data_end;
    
    struct iphdr *iph = data;
    if ((void *)iph + sizeof(*iph) > data_end)
        return TC_ACT_OK;
    
    // Check if ICMP packet
    if (iph->protocol != IPPROTO_ICMP)
        return TC_ACT_OK;
    
    // Check destination IP (8.8.8.8 = 0x08080808)
    if (iph->daddr != 0x08080808)
        return TC_ACT_OK;
    
    // Block this ICMP packet
    bpf_printk("Blocking ICMP to 8.8.8.8");
    return TC_ACT_SHOT;  // Drop packet
}

char _license[] SEC("license") = "GPL";
